import React, { useState, useEffect } from "react";

const Crypto = () => {
  const [cryptoData, setCryptoData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    const fetchCryptoPrices = async () => {
      try {
        console.log("Fetching cryptocurrency data...");
        setLoading(true);
        const response = await fetch(
          "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false",
          { signal: controller.signal }
        );
        if (!response.ok) throw new Error(`API Error: ${response.status} - ${response.statusText}`);

        const data = await response.json();
        console.log("Fetched Data:", data);

        setCryptoData(data);
      } catch (err) {
        if (err.name !== "AbortError") {
          console.error("Fetch Error:", err);
          setError(err.message);
        }
      } finally {
        setLoading(false);
      }
    };

    fetchCryptoPrices();
    const interval = setInterval(fetchCryptoPrices, 10000);

    return () => {
      clearInterval(interval);
      controller.abort();
    };
  }, []);

  return (
    <div style={{ textAlign: "center", backgroundColor: "#f4f4f4", minHeight: "100vh", padding: "20px" }}>
      <h1>Live Cryptocurrency Prices</h1>

      {loading && <p>Loading data...</p>}
      {error && <p style={{ color: "red" }}>Error: {error}</p>}

      {!loading && !error && cryptoData.length > 0 ? (
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "80%", margin: "20px auto", borderCollapse: "collapse", background: "white" }}>
            <thead>
              <tr style={{ backgroundColor: "#333", color: "white" }}>
                <th style={{ padding: "10px", border: "1px solid #ddd" }}>Name</th>
                <th style={{ padding: "10px", border: "1px solid #ddd" }}>Symbol</th>
                <th style={{ padding: "10px", border: "1px solid #ddd" }}>Price (USD)</th>
              </tr>
            </thead>
            <tbody>
              {cryptoData.map((crypto) => (
                <tr key={crypto.id} style={{ backgroundColor: "#f9f9f9" }}>
                  <td style={{ padding: "10px", border: "1px solid #ddd" }}>{crypto.name}</td>
                  <td style={{ padding: "10px", border: "1px solid #ddd", textTransform: "uppercase" }}>{crypto.symbol}</td>
                  <td style={{ padding: "10px", border: "1px solid #ddd" }}>${crypto.current_price.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        !loading && !error && <p>No data available</p>
      )}
    </div>
  );
};

export default Crypto;
